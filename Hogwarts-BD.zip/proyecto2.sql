create table colegio(
	id varchar2(40) primary key,
	nro_estudiantes number check(nro_estudiantes>=0),
	nro_profesores number check(nro_profesores>=0),
	mts2 number check(mts2>=0),
	fecha_fundacion date,
	director_actual varchar2(100) not null
 );


create table casa(
	id_colegio varchar2(40),
	nombre varchar2(100) primary key,
	fundador varchar2(100) not null,
	colores varchar2(100) not null,
	animal varchar2(100) not null,
	rasgos varchar2(100) not null,
	jefe_actual varchar2(100) not null,
	fantasma varchar2(100) not null,
	sala_comun varchar2(100) not null,
	foreign key (id_colegio) references colegio (id)
 );

create table persona(
	id varchar2(40) primary key,
	nombre varchar2(100) not null,
	fecha_nacimiento date,
	estatus_sangre varchar2(100), 
	estado_civil varchar2(100),
	apodos varchar2(100) not null,
	especie varchar2(100) not null,
	sexo varchar2(2),
	color_cabello varchar2(100),
	color_ojos varchar2(100),
	villano varchar2(2)
 );

create table profesor(
	id varchar2(40) primary key,
	titulos varchar2(100),
	anio_graduacion date,
	foreign key (id) references persona (id)
);

create table estudiante(
	id varchar2(40) primary key,
	id_colegio varchar2(40),
	nombre_casa varchar2(100),
	patronus varchar2(100),
	foreign key (id) references persona (id),
	foreign key (id_colegio) references colegio (id),
	foreign key (nombre_casa) references casa (nombre)
);	



create table materia(
	codigo varchar2(40) primary key,
	nombre varchar2(100) not null,
	libros_requeridos varchar2(100) not null,
	material_requerido varchar2(100) not null,
	num_creditos number check(num_creditos>=0)
);	

create table tipo_hechizo(
	codigo varchar2(40) primary key,
	nombre varchar2(100) not null
);

create table hechizo(
	codigo varchar2(40) primary key,
	conjuro varchar2(100) not null,
	cod_tipo_hechizo varchar2(40),
	movimiento varchar2(100),
	luz varchar2(100),
	efecto varchar2(100),
	creador varchar2(100) not null,
	puntos_ataque number check(puntos_ataque>=0),
	foreign key (cod_tipo_hechizo) references tipo_hechizo (codigo)
);

create table aprende(
	id_persona varchar2(40) not null,
	codigo_hechizo varchar2(40) not null,
	foreign key (id_persona) references persona (id),
	foreign key (codigo_hechizo) references hechizo (codigo),
	primary key (id_persona,codigo_hechizo)
);


create table grupo_hechizo(
	id_grupo varchar2(40)primary key,
	codigo_hechizo_1 varchar2(40),
	codigo_hechizo_2 varchar2(40),
	codigo_hechizo_3 varchar2(40),
	codigo_hechizo_4 varchar2(40),
	codigo_hechizo_5 varchar2(40),
	codigo_hechizo_6 varchar2(40),
	foreign key (codigo_hechizo_1) references hechizo (codigo),
	foreign key (codigo_hechizo_2) references hechizo (codigo),
	foreign key (codigo_hechizo_3) references hechizo (codigo),
	foreign key (codigo_hechizo_4) references hechizo (codigo),
	foreign key (codigo_hechizo_5) references hechizo (codigo),
	foreign key (codigo_hechizo_6) references hechizo (codigo)
);

create table batalla(
	id_estudiante_1 varchar2(40) not null,
	id_estudiante_2 varchar2(40) not null,
	id_grupo_hechizo varchar2(40),
	fecha date,
	lugar varchar2(100),      --LLEVA RESTRICCION
	ganador varchar2(100) not null,
	foreign key (id_estudiante_1) references estudiante (id),
	foreign key (id_estudiante_2) references estudiante (id),
	foreign key (id_grupo_hechizo) references grupo_hechizo (id_grupo),
	primary key (id_estudiante_1,id_estudiante_2,id_grupo_hechizo)
);

create table cursa(
	id_estudiante varchar2(40) not null,
	codigo_materia varchar2(40) not null,
	id_profesor varchar2(40),
	anio_escolar number check(anio_escolar>=0),
	nota number check(nota>=0 AND nota<=20),
	foreign key (id_estudiante) references estudiante (id),
	foreign key (codigo_materia) references materia (codigo),
	foreign key (id_profesor) references profesor (id)
);


insert into Colegio 
	( id , nro_estudiantes, nro_profesores, mts2, fecha_fundacion, director_actual) values ('Colegio Hogwarts de Magia y Hechiceria', 25, 15,200000, TO_DATE('01/12/0990','dd/mm/yyyy'),'Albus Dumbledore');

--Casa ( id_colegio , nombre , fundador, colores, animal, rasgos, jefe_actual, fantasma,sala_comun)

insert into Casa
( id_colegio , nombre , fundador, colores, animal, rasgos, jefe_actual, fantasma, sala_comun) values ('Colegio Hogwarts de Magia y Hechiceria' ,'Gryffindor','Godric Gryffindor','Escarlata y Dorado','leon','valentía, disposición y coraje','Minerva McGonagall','Nicholas de Mimsy-Porpington','Torre de Gryffindor');

insert into Casa
( id_colegio , nombre , fundador, colores, animal, rasgos, jefe_actual, fantasma, sala_comun)values('Colegio Hogwarts de Magia y Hechiceria' ,'Hufflepuff','Helga Hufflepuff','Amarillo y Negro','Tejón','Lealtad, dedicación y trabajo duro','Pomona Sprout','Fraile Gordo','Cerca de la cocina del castillo');

insert into Casa
( id_colegio , nombre , fundador, colores, animal, rasgos, jefe_actual, fantasma, sala_comun)values('Colegio Hogwarts de Magia y Hechiceria' ,'Ravenclaw','Rowena Ravenclaw','Azul y bronce','Águila','Inteligencia e Ingenio','Filius Flitwick','Dama Gris','Torre de Ravenclaw');

insert into Casa
( id_colegio , nombre , fundador, colores, animal, rasgos, jefe_actual, fantasma, sala_comun)values('Colegio Hogwarts de Magia y Hechiceria' ,'Slytherin','Salazar Slytherin','Verde y plata','Serpiente','Ambición, astucia, determinación, ingenio, auto-preservación','Severus Snape','Barón Sanguinario','Mazmorras de Slytherin');


insert ALL
	into persona( id , nombre, fecha_nacimiento, estatus_sangre, estado_civil, apodos, especie, sexo,color_cabello, color_ojos, villano) values ( 0 , 'Minerva McGonagall',TO_DATE('04/10/1935','dd/mm/yyyy') , 'Sangre mestiza', 'Viuda', 'McGonagall', 'Humana', 'F','Negro', 'Verdes', 'F')
	into persona( id , nombre, fecha_nacimiento, estatus_sangre, estado_civil, apodos, especie, sexo,color_cabello, color_ojos, villano) values ( 1 , 'Dolores Umbridge',TO_DATE('26/08/1965','dd/mm/yyyy') , 'Sangre mestiza', 'Soltera', 'Madame', 'Humana', 'F','Castaño', 'Verdes', 'T')
	into persona( id , nombre, fecha_nacimiento, estatus_sangre, estado_civil, apodos, especie, sexo,color_cabello, color_ojos, villano) values ( 2 , 'Severus Snape',TO_DATE('02/05/1960','dd/mm/yyyy') , 'Sangre mestiza', 'Soltero', 'Príncipe Mestizo', 'Humano', 'M','Negro', 'Negros', 'T')
	into persona( id , nombre, fecha_nacimiento, estatus_sangre, estado_civil, apodos, especie, sexo,color_cabello, color_ojos, villano) values ( 3 , 'Alecto Carrow',TO_DATE('01/01/1970','dd/mm/yyyy') , 'Sangre pura', 'Soltera', 'Mortífago', 'Humana', 'F','Rubio', 'Negro', 'T')
	into persona( id , nombre, fecha_nacimiento, estatus_sangre, estado_civil, apodos, especie, sexo,color_cabello, color_ojos, villano) values ( 4 , 'Albus Dumbledore',TO_DATE('04/03/1881','dd/mm/yyyy') , 'Sangre mestiza', 'Soltero', 'Profesor', 'Humano', 'M','Plateado', 'Azules', 'F')
	into persona( id , nombre, fecha_nacimiento, estatus_sangre, estado_civil, apodos, especie, sexo,color_cabello, color_ojos, villano) values ( 5 , 'Quirinus Quirrell',TO_DATE('26/09/1950','dd/mm/yyyy') , 'Sangre mestiza', 'Soltero', 'Profesor', 'Humano', 'M','Calvo', 'Azules', 'T')
	into persona( id , nombre, fecha_nacimiento, estatus_sangre, estado_civil, apodos, especie, sexo,color_cabello, color_ojos, villano) values ( 6 , 'Gilderoy Lockhart',TO_DATE('26/01/1950','dd/mm/yyyy') , 'Sangre mestiza', 'Soltero', 'Profesor', 'Humano', 'M','Rubio', 'Azules', 'F')
	into persona( id , nombre, fecha_nacimiento, estatus_sangre, estado_civil, apodos, especie, sexo,color_cabello, color_ojos, villano) values ( 7 , 'Remus John Lupin',TO_DATE('10/03/1960','dd/mm/yyyy') , 'Sangre mestiza', 'Casado', 'Lunático', 'Humano', 'M','Castaño', 'Marrones', 'F')
	into persona( id , nombre, fecha_nacimiento, estatus_sangre, estado_civil, apodos, especie, sexo,color_cabello, color_ojos, villano) values ( 8 , 'Alastor Moody',TO_DATE('27/07/1997','dd/mm/yyyy') , 'Sangre pura', 'Soltero', 'Ojoloco', 'Humano', 'M','Canoso', 'Cafe-Azul', 'F')
	into persona( id , nombre, fecha_nacimiento, estatus_sangre, estado_civil, apodos, especie, sexo,color_cabello, color_ojos, villano) values ( 9 , 'Pomona Sprout',TO_DATE('15/05/1931','dd/mm/yyyy') , 'Sangre pura', 'Casada', 'Madame', 'Humana', 'F','Canoso', 'Cafes', 'F')
select * from dual;
insert ALL
	into profesor(id , titulos, anio_graduacion) values (0, 'Profesora',TO_DATE('13/06/1953', 'dd/mm/yyyy'))
	into profesor(id , titulos, anio_graduacion) values (1, 'Subsecretaria del Ministro de Magia',TO_DATE('13/06/1983', 'dd/mm/yyyy'))
	into profesor(id , titulos, anio_graduacion) values (2, 'Jefe de la Casa Slytherin',TO_DATE('13/06/1978', 'dd/mm/yyyy'))
	into profesor(id , titulos, anio_graduacion) values (3, 'Profesora',TO_DATE('13/06/1988', 'dd/mm/yyyy'))
	into profesor(id , titulos, anio_graduacion) values (4, 'Gran Hechicero',TO_DATE('13/06/1898', 'dd/mm/yyyy'))
	into profesor(id , titulos, anio_graduacion) values (5, 'Profesor',TO_DATE('13/06/1968', 'dd/mm/yyyy'))
	into profesor(id , titulos, anio_graduacion) values (6, 'Afamado Escritor',TO_DATE('13/06/1968', 'dd/mm/yyyy'))
	into profesor(id , titulos, anio_graduacion) values (7, 'Prefecto',TO_DATE('13/06/1978', 'dd/mm/yyyy'))
	into profesor(id , titulos, anio_graduacion) values (8, 'Auror',TO_DATE('13/06/2015', 'dd/mm/yyyy'))
	into profesor(id , titulos, anio_graduacion) values (9, 'Jefa del Departamento de Herbología',TO_DATE('13/06/1949', 'dd/mm/yyyy'))
select * from dual;
--Persona ( id , nombre, fecha_nacimiento, estatus_sangre, estado_civil, apodos, especie, sexo, color_cabello, color_ojos, villano)
insert ALL
	into persona( id , nombre, fecha_nacimiento, estatus_sangre, estado_civil, apodos, especie, sexo, color_cabello, color_ojos, villano) values ( 10 , 'Harry Potter',TO_DATE('31/07/1980','dd/mm/yyyy') , 'Sangre mestiza', 'Soltero', 'El Niño Que Sobrevivió', 'Humano', 'M','Negro', 'Verdes', 'F')
	into persona( id , nombre, fecha_nacimiento, estatus_sangre, estado_civil, apodos, especie, sexo, color_cabello, color_ojos, villano) values ( 11 , 'Ronald Weasley',TO_DATE('01/03/1980','dd/mm/yyyy') , 'Sangre pura', 'Soltero', 'Rupert', 'Humano', 'M','Pelirrojo', 'Azules', 'F')
	into persona( id , nombre, fecha_nacimiento, estatus_sangre, estado_civil, apodos, especie, sexo, color_cabello, color_ojos, villano) values ( 12 , 'Hermione Granger',TO_DATE('19/09/1979','dd/mm/yyyy') , 'Sangre sucia', 'Soltera', 'Asquerosa sangre sucia', 'Humana', 'F','Castaño', 'Marrones', 'F')
	into persona( id , nombre, fecha_nacimiento, estatus_sangre, estado_civil, apodos, especie, sexo, color_cabello, color_ojos, villano) values ( 13 , 'George Weasley',TO_DATE('01/04/1978','dd/mm/yyyy') , 'Sangre pura', 'Soltero', 'Gred', 'Humano', 'M','Pelirrojo', 'Marrones', 'F')
	into persona( id , nombre, fecha_nacimiento, estatus_sangre, estado_civil, apodos, especie, sexo, color_cabello, color_ojos, villano) values ( 14 , 'Fred Weasley',TO_DATE('01/04/1978','dd/mm/yyyy') , 'Sangre pura', 'Soltero', 'Fred', 'Humano', 'M','Pelirrojo', 'Marrones', 'F')
	into persona( id , nombre, fecha_nacimiento, estatus_sangre, estado_civil, apodos, especie, sexo, color_cabello, color_ojos, villano) values ( 15 , 'Ernie Macmillan',TO_DATE('02/03/1980','dd/mm/yyyy') , 'Sangre pura', 'Soltero', 'Ernie', 'Humano', 'M','Rubio', 'Marrones', 'F')
	into persona( id , nombre, fecha_nacimiento, estatus_sangre, estado_civil, apodos, especie, sexo, color_cabello, color_ojos, villano) values ( 16 , 'Hannah Longbottom',TO_DATE('14/02/1980','dd/mm/yyyy') , 'Sangre mestiza', 'Soltera', 'Hannah', 'Humana', 'F','Rubio', 'Marrones', 'F')
	into persona( id , nombre, fecha_nacimiento, estatus_sangre, estado_civil, apodos, especie, sexo, color_cabello, color_ojos, villano) values ( 17 , 'Karl Limpley',TO_DATE('02/01/1982','dd/mm/yyyy') , 'Sangre mestiza', 'Soltero', 'Karl', 'Humano', 'M','Castaño', 'Negros', 'F')
	into persona( id , nombre, fecha_nacimiento, estatus_sangre, estado_civil, apodos, especie, sexo, color_cabello, color_ojos, villano) values ( 18 , 'Justin Finch-Fletchley',TO_DATE('03/03/1980','dd/mm/yyyy') , 'Sangre sucia', 'Soltero', 'Justin', 'Humano', 'M','Castaño', 'Marrones', 'F')
	into persona( id , nombre, fecha_nacimiento, estatus_sangre, estado_civil, apodos, especie, sexo, color_cabello, color_ojos, villano) values ( 19 , 'Susan Bones',TO_DATE('04/04/1980','dd/mm/yyyy') , 'Sangre mestiza', 'Soltera', 'Susan', 'Humana', 'F','Pelirrojo', 'Marrones', 'F')
	into persona( id , nombre, fecha_nacimiento, estatus_sangre, estado_civil, apodos, especie, sexo, color_cabello, color_ojos, villano) values ( 20 , 'Alannis',TO_DATE('05/05/1979','dd/mm/yyyy') , 'Sangre pura', 'Soltera', 'Alannis', 'Humana', 'F','Rubio', 'Azules', 'F')
	into persona( id , nombre, fecha_nacimiento, estatus_sangre, estado_civil, apodos, especie, sexo, color_cabello, color_ojos, villano) values ( 21 , 'Andrew',TO_DATE('06/06/1981','dd/mm/yyyy') , 'Sangre pura', 'Soltero', 'Andrew', 'Humano', 'M','Negro', 'Marrones', 'F')
	into persona( id , nombre, fecha_nacimiento, estatus_sangre, estado_civil, apodos, especie, sexo, color_cabello, color_ojos, villano) values ( 22 , 'Helen Dawlish',TO_DATE('19/11/1982','dd/mm/yyyy') , 'Sangre sucia', 'Soltera', 'Helen', 'Humana', 'F','Castaño', 'Marrones', 'F')
	into persona( id , nombre, fecha_nacimiento, estatus_sangre, estado_civil, apodos, especie, sexo, color_cabello, color_ojos, villano) values ( 23 , 'Rebecca',TO_DATE('25/11/1975','dd/mm/yyyy') , 'Sangre pura', 'Soltero', 'Rebecca', 'Humana', 'F','Castaño', 'Marrones', 'F')
	into persona( id , nombre, fecha_nacimiento, estatus_sangre, estado_civil, apodos, especie, sexo, color_cabello, color_ojos, villano) values ( 24 , 'Shoma Ichikawa',TO_DATE('24/12/1982','dd/mm/yyyy') , 'Sangre pura', 'Soltero', 'Shoma', 'Humano', 'M','Negro', 'Verdes', 'F')
	into persona( id , nombre, fecha_nacimiento, estatus_sangre, estado_civil, apodos, especie, sexo, color_cabello, color_ojos, villano) values ( 25 , 'Draco Malfoy',TO_DATE('05/06/1980','dd/mm/yyyy') , 'Sangre pura', 'Viudo', 'El increíble hurón saltarín', 'Humano', 'M','Rubio', 'Gris', 'T')
	into persona( id , nombre, fecha_nacimiento, estatus_sangre, estado_civil, apodos, especie, sexo, color_cabello, color_ojos, villano) values ( 26 , 'Fergus Cowley',TO_DATE('19/12/1985','dd/mm/yyyy') , 'Sangre pura', 'Solter0', 'Fer', 'Humano', 'M','Negro', 'Negros', 'T')
	into persona( id , nombre, fecha_nacimiento, estatus_sangre, estado_civil, apodos, especie, sexo, color_cabello, color_ojos, villano) values ( 27 , 'Irfan Mustaq',TO_DATE('20/10/1982','dd/mm/yyyy') , 'Sangre pura', 'Soltero', 'Mustaq', 'Humano', 'M','Rubio', 'Verdes', 'F')
	into persona( id , nombre, fecha_nacimiento, estatus_sangre, estado_civil, apodos, especie, sexo, color_cabello, color_ojos, villano) values ( 28 , 'Maynard Hatton',TO_DATE('29/10/1982','dd/mm/yyyy') , 'Sangre pura', 'Soltero', 'May', 'Humano', 'M','Castaño', 'Azules', 'F')
	into persona( id , nombre, fecha_nacimiento, estatus_sangre, estado_civil, apodos, especie, sexo, color_cabello, color_ojos, villano) values ( 29 , 'Millicent Bulstrode',TO_DATE('03/02/1980','dd/mm/yyyy') , 'Sangre pura', 'Soltera', 'Milly', 'Humana', 'F','Castaño', 'Marrones', 'F')
select * from dual;
--	Estudiante ( id , id_colegio , nombre_casa , patronus)
insert ALL
into estudiante( id , id_colegio , nombre_casa , patronus) values (10,'Colegio Hogwarts de Magia y Hechiceria','Gryffindor','Ciervo')
into estudiante( id , id_colegio , nombre_casa , patronus) values (11,'Colegio Hogwarts de Magia y Hechiceria','Gryffindor','Perro')
into estudiante( id , id_colegio , nombre_casa , patronus) values (12,'Colegio Hogwarts de Magia y Hechiceria','Gryffindor','Gato')
into estudiante( id , id_colegio , nombre_casa , patronus) values (13,'Colegio Hogwarts de Magia y Hechiceria','Gryffindor','Hamster')
into estudiante( id , id_colegio , nombre_casa , patronus) values (14,'Colegio Hogwarts de Magia y Hechiceria','Gryffindor','Burro')
into estudiante( id , id_colegio , nombre_casa , patronus) values (15,'Colegio Hogwarts de Magia y Hechiceria','Hufflepuff','Turpial')
into estudiante( id , id_colegio , nombre_casa , patronus) values (16,'Colegio Hogwarts de Magia y Hechiceria','Hufflepuff','Guacamaya')
into estudiante( id , id_colegio , nombre_casa , patronus) values (17,'Colegio Hogwarts de Magia y Hechiceria','Hufflepuff','Zamuro')
into estudiante( id , id_colegio , nombre_casa , patronus) values (18,'Colegio Hogwarts de Magia y Hechiceria','Hufflepuff','Zancudo')
into estudiante( id , id_colegio , nombre_casa , patronus) values (19,'Colegio Hogwarts de Magia y Hechiceria','Hufflepuff','Loro')
into estudiante( id , id_colegio , nombre_casa , patronus) values (20,'Colegio Hogwarts de Magia y Hechiceria','Ravenclaw','Cucaracha')
into estudiante( id , id_colegio , nombre_casa , patronus) values (21,'Colegio Hogwarts de Magia y Hechiceria','Ravenclaw','Saltamontes')
into estudiante( id , id_colegio , nombre_casa , patronus) values (22,'Colegio Hogwarts de Magia y Hechiceria','Ravenclaw','Caballo')
into estudiante( id , id_colegio , nombre_casa , patronus) values (23,'Colegio Hogwarts de Magia y Hechiceria','Ravenclaw','Chigüire')
into estudiante( id , id_colegio , nombre_casa , patronus) values (24,'Colegio Hogwarts de Magia y Hechiceria','Ravenclaw','Lapa')
into estudiante( id , id_colegio , nombre_casa , patronus) values (25,'Colegio Hogwarts de Magia y Hechiceria','Slytherin','Serpiente')
into estudiante( id , id_colegio , nombre_casa , patronus) values (26,'Colegio Hogwarts de Magia y Hechiceria','Slytherin','Cienpies')
into estudiante( id , id_colegio , nombre_casa , patronus) values (27,'Colegio Hogwarts de Magia y Hechiceria','Slytherin','Tarantula')
into estudiante( id , id_colegio , nombre_casa , patronus) values (28,'Colegio Hogwarts de Magia y Hechiceria','Slytherin','Rata')
into estudiante( id , id_colegio , nombre_casa , patronus) values (29,'Colegio Hogwarts de Magia y Hechiceria','Slytherin','Escorpion')
select * from dual;
--Materia ( codigo , nombre, libros_requeridos, material_requerido, num_creditos)
insert ALL
into materia (codigo , nombre, libros_requeridos, material_requerido, num_creditos) values ( 101 , 'Transformaciones 1', 'Transformaciones for dummies', 'Ganas, pelo de Hermione', '10')
into materia (codigo , nombre, libros_requeridos, material_requerido, num_creditos) values ( 102 , 'Defensa Contra las Artes Oscuras 1', 'D.C.A.O for dummies', 'Varita, chocolates para el profesor', '10')
into materia (codigo , nombre, libros_requeridos, material_requerido, num_creditos) values ( 103 , 'Pociones', 'Pociones for dummies', 'Frascos de Vidrio, Anis, preveral, cocuy, baygon, moneda de oro', '10')
into materia (codigo , nombre, libros_requeridos, material_requerido, num_creditos) values ( 104 , 'Estudios Muggles 1', 'Cualquiera', 'Laptop, Telefono inteligente, Cargadores, botella para el profesor', '10')
into materia (codigo , nombre, libros_requeridos, material_requerido, num_creditos) values ( 105 , 'Transformaciones 2', 'Transformaciones for pro', 'Varita con iOS 10+, 1 Gato', '10')
into materia (codigo , nombre, libros_requeridos, material_requerido, num_creditos) values ( 106 , 'Defensa Contra las Artes Oscuras 2', 'D.C.A.O for dummies Part 2', 'Brownies para el profesor, Varita con iOS 10+', '10')
into materia (codigo , nombre, libros_requeridos, material_requerido, num_creditos) values ( 107 , 'Defensa Contra las Artes Oscuras 3', 'D.C.A.O for dummies Part 3', 'Par de bolas, Telefono inteligente', '10')
into materia (codigo , nombre, libros_requeridos, material_requerido, num_creditos) values ( 108 , 'Defensa Contra las Artes Oscuras 3', 'D.C.A.O for dummies Part 4', 'Par de bolas, varitas variadas', '10')
into materia (codigo , nombre, libros_requeridos, material_requerido, num_creditos) values ( 109 , 'Defensa Contra las Artes Oscuras 5', 'Como guarimbear', 'Par de bolas, puputovs, guantes', '10')
into materia (codigo , nombre, libros_requeridos, material_requerido, num_creditos) values ( 110 , 'Herbología', 'Herbología for dummies', 'Matica, pala, guantes', '10')
select * from dual;
--Tipo_Hechizo ( codigo , nombre)
insert ALL
into tipo_hechizo ( codigo , nombre) values (1,'Transformación')
into tipo_hechizo ( codigo , nombre) values (2,'Embrujo')
into tipo_hechizo ( codigo , nombre) values (3,'Maleficio')
into tipo_hechizo ( codigo , nombre) values (4,'Encantamiento')
into tipo_hechizo ( codigo , nombre) values (5,'Maldición')
select * from dual;
--Hechizo ( codigo , conjuro, cod_tipo_hechizo , movimiento, luz, efecto, creador, puntos_ataque)
insert ALL
into hechizo ( codigo , conjuro, cod_tipo_hechizo , movimiento, luz, efecto, creador, puntos_ataque) values (101, 'Badgering', 1, 'tal', 'roja', 'transforma', 'dios', '100')
into hechizo ( codigo , conjuro, cod_tipo_hechizo , movimiento, luz, efecto, creador, puntos_ataque) values (102, 'Caldero a cedazo', 1, 'tal', 'roja', 'transforma', 'dios', '110')
into hechizo ( codigo , conjuro, cod_tipo_hechizo , movimiento, luz, efecto, creador, puntos_ataque) values (103, 'Crinus Muto', 1, 'tal', 'roja', 'transforma', 'dios', '120')
into hechizo ( codigo , conjuro, cod_tipo_hechizo , movimiento, luz, efecto, creador, puntos_ataque) values (104, 'Ducklifors', 1, 'tal', 'roja', 'transforma', 'dios', '130')
into hechizo ( codigo , conjuro, cod_tipo_hechizo , movimiento, luz, efecto, creador, puntos_ataque) values (105, 'Herbifors', 1, 'tal', 'roja', 'transforma', 'dios', '140')
into hechizo ( codigo , conjuro, cod_tipo_hechizo , movimiento, luz, efecto, creador, puntos_ataque) values (201, 'Cantis', 2, 'tal', 'blanca', 'embruja', 'dios', '150')
into hechizo ( codigo , conjuro, cod_tipo_hechizo , movimiento, luz, efecto, creador, puntos_ataque) values (202, 'Ebublio', 2, 'tal', 'blanca', 'embruja', 'dios', '160')
into hechizo ( codigo , conjuro, cod_tipo_hechizo , movimiento, luz, efecto, creador, puntos_ataque) values (203, 'Furnunculus', 2, 'tal', 'blanca', 'embruja', 'dios', '170')
into hechizo ( codigo , conjuro, cod_tipo_hechizo , movimiento, luz, efecto, creador, puntos_ataque) values (204, 'Gusarajus', 2, 'tal', 'blanca', 'embruja', 'dios', '180')
into hechizo ( codigo , conjuro, cod_tipo_hechizo , movimiento, luz, efecto, creador, puntos_ataque) values (205, 'Melofors', 2, 'tal', 'blanca', 'embruja', 'dios', '190')
into hechizo ( codigo , conjuro, cod_tipo_hechizo , movimiento, luz, efecto, creador, puntos_ataque) values (301, 'Titillando', 3, 'tal', 'purpura', 'maleficia', 'dios', '100')
into hechizo ( codigo , conjuro, cod_tipo_hechizo , movimiento, luz, efecto, creador, puntos_ataque) values (302, 'Densaugeo', 3, 'tal', 'purpura', 'maleficia', 'dios', '110')
into hechizo ( codigo , conjuro, cod_tipo_hechizo , movimiento, luz, efecto, creador, puntos_ataque) values (303, 'Anteoculatia', 3, 'tal', 'purpura', 'maleficia', 'dios', '120')
into hechizo ( codigo , conjuro, cod_tipo_hechizo , movimiento, luz, efecto, creador, puntos_ataque) values (304, 'Steleus', 3, 'tal', 'purpura', 'maleficia', 'dios', '130')
into hechizo ( codigo , conjuro, cod_tipo_hechizo , movimiento, luz, efecto, creador, puntos_ataque) values (305, 'Colloshoo', 3, 'tal', 'purpura', 'maleficia', 'dios', '140')
into hechizo ( codigo , conjuro, cod_tipo_hechizo , movimiento, luz, efecto, creador, puntos_ataque) values (401, 'Spongify', 4, 'tal', 'amarilla', 'encanta', 'dios', '150')
into hechizo ( codigo , conjuro, cod_tipo_hechizo , movimiento, luz, efecto, creador, puntos_ataque) values (402, 'Quietus', 4, 'tal', 'amarilla', 'encanta', 'dios', '160')
into hechizo ( codigo , conjuro, cod_tipo_hechizo , movimiento, luz, efecto, creador, puntos_ataque) values (403, 'Molliare', 4, 'tal', 'amarilla', 'encanta', 'dios', '170')
into hechizo ( codigo , conjuro, cod_tipo_hechizo , movimiento, luz, efecto, creador, puntos_ataque) values (404, 'Sonorus', 4, 'tal', 'amarilla', 'encanta', 'dios', '180')
into hechizo ( codigo , conjuro, cod_tipo_hechizo , movimiento, luz, efecto, creador, puntos_ataque) values (405, 'Aqua Eructo', 4, 'tal', 'amarilla', 'encanta', 'dios', '190')
into hechizo ( codigo , conjuro, cod_tipo_hechizo , movimiento, luz, efecto, creador, puntos_ataque) values (501, 'Geminio', 5, 'tal', 'verde', 'maldice', 'dios', '250')
into hechizo ( codigo , conjuro, cod_tipo_hechizo , movimiento, luz, efecto, creador, puntos_ataque) values (502, 'Expulso', 5, 'tal', 'verde', 'maldice', 'dios', '260')
into hechizo ( codigo , conjuro, cod_tipo_hechizo , movimiento, luz, efecto, creador, puntos_ataque) values (503, 'Confringo', 5, 'tal', 'verde', 'maldice', 'dios', '270')
into hechizo ( codigo , conjuro, cod_tipo_hechizo , movimiento, luz, efecto, creador, puntos_ataque) values (504, 'Crucio', 5, 'tal', 'verde', 'maldice', 'dios', '280')
into hechizo ( codigo , conjuro, cod_tipo_hechizo , movimiento, luz, efecto, creador, puntos_ataque) values (505, 'Avada Kedavra', 5, 'tal', 'verde', 'maldice', 'dios', '290')
select * from dual;
--Aprende ( id_persona , codigo_hechizo )
insert ALL
into aprende ( id_persona , codigo_hechizo ) values ( 10 , 101 )
into aprende ( id_persona , codigo_hechizo ) values ( 10 , 201 )
into aprende ( id_persona , codigo_hechizo ) values ( 10 , 301 )
into aprende ( id_persona , codigo_hechizo ) values ( 11 , 102 )
into aprende ( id_persona , codigo_hechizo ) values ( 11 , 202 )
into aprende ( id_persona , codigo_hechizo ) values ( 11 , 302 )
into aprende ( id_persona , codigo_hechizo ) values ( 12 , 101 )
into aprende ( id_persona , codigo_hechizo ) values ( 12 , 102 )
into aprende ( id_persona , codigo_hechizo ) values ( 12 , 103 )
into aprende ( id_persona , codigo_hechizo ) values ( 12 , 104 )
into aprende ( id_persona , codigo_hechizo ) values ( 12 , 105 )
into aprende ( id_persona , codigo_hechizo ) values ( 12 , 201 )
into aprende ( id_persona , codigo_hechizo ) values ( 12 , 202 )
into aprende ( id_persona , codigo_hechizo ) values ( 12 , 203 )
into aprende ( id_persona , codigo_hechizo ) values ( 12 , 204 )
into aprende ( id_persona , codigo_hechizo ) values ( 12 , 205 )
into aprende ( id_persona , codigo_hechizo ) values ( 12 , 301 )
into aprende ( id_persona , codigo_hechizo ) values ( 12 , 302 )
into aprende ( id_persona , codigo_hechizo ) values ( 12 , 303 )
into aprende ( id_persona , codigo_hechizo ) values ( 12 , 304 )
into aprende ( id_persona , codigo_hechizo ) values ( 12 , 305 )
into aprende ( id_persona , codigo_hechizo ) values ( 12 , 401 )
into aprende ( id_persona , codigo_hechizo ) values ( 12 , 402 )
into aprende ( id_persona , codigo_hechizo ) values ( 12 , 403 )
into aprende ( id_persona , codigo_hechizo ) values ( 12 , 404 )
into aprende ( id_persona , codigo_hechizo ) values ( 12 , 405 )
into aprende ( id_persona , codigo_hechizo ) values ( 12 , 501 )
into aprende ( id_persona , codigo_hechizo ) values ( 12 , 502 )
into aprende ( id_persona , codigo_hechizo ) values ( 12 , 503 )
into aprende ( id_persona , codigo_hechizo ) values ( 12 , 504 )
into aprende ( id_persona , codigo_hechizo ) values ( 12 , 505 )
into aprende ( id_persona , codigo_hechizo ) values ( 13 , 303 )
into aprende ( id_persona , codigo_hechizo ) values ( 13 , 403 )
into aprende ( id_persona , codigo_hechizo ) values ( 13 , 503 )
into aprende ( id_persona , codigo_hechizo ) values ( 14 , 104 )
into aprende ( id_persona , codigo_hechizo ) values ( 14 , 204 )
into aprende ( id_persona , codigo_hechizo ) values ( 14 , 304 )
into aprende ( id_persona , codigo_hechizo ) values ( 15 , 405 )
into aprende ( id_persona , codigo_hechizo ) values ( 15 , 505 )
into aprende ( id_persona , codigo_hechizo ) values ( 15 , 105 )
into aprende ( id_persona , codigo_hechizo ) values ( 16 , 201 )
into aprende ( id_persona , codigo_hechizo ) values ( 16 , 301 )
into aprende ( id_persona , codigo_hechizo ) values ( 16 , 401 )
into aprende ( id_persona , codigo_hechizo ) values ( 17 , 502 )
into aprende ( id_persona , codigo_hechizo ) values ( 17 , 102 )
into aprende ( id_persona , codigo_hechizo ) values ( 17 , 202 )
into aprende ( id_persona , codigo_hechizo ) values ( 18 , 303 )
into aprende ( id_persona , codigo_hechizo ) values ( 18 , 403 )
into aprende ( id_persona , codigo_hechizo ) values ( 18 , 503 )
into aprende ( id_persona , codigo_hechizo ) values ( 19 , 104 )
into aprende ( id_persona , codigo_hechizo ) values ( 19 , 204 )
into aprende ( id_persona , codigo_hechizo ) values ( 19 , 304 )
into aprende ( id_persona , codigo_hechizo ) values ( 20 , 405 )
into aprende ( id_persona , codigo_hechizo ) values ( 20 , 505 )
into aprende ( id_persona , codigo_hechizo ) values ( 20 , 105 )
into aprende ( id_persona , codigo_hechizo ) values ( 21 , 201 )
into aprende ( id_persona , codigo_hechizo ) values ( 21 , 301 )
into aprende ( id_persona , codigo_hechizo ) values ( 21 , 401 )
into aprende ( id_persona , codigo_hechizo ) values ( 22 , 502 )
into aprende ( id_persona , codigo_hechizo ) values ( 22 , 102 )
into aprende ( id_persona , codigo_hechizo ) values ( 22 , 202 )
into aprende ( id_persona , codigo_hechizo ) values ( 23 , 303 )
into aprende ( id_persona , codigo_hechizo ) values ( 23 , 403 )
into aprende ( id_persona , codigo_hechizo ) values ( 23 , 503 )
into aprende ( id_persona , codigo_hechizo ) values ( 24 , 104 )
into aprende ( id_persona , codigo_hechizo ) values ( 24 , 204 )
into aprende ( id_persona , codigo_hechizo ) values ( 24 , 304 )
into aprende ( id_persona , codigo_hechizo ) values ( 25 , 405 )
into aprende ( id_persona , codigo_hechizo ) values ( 25 , 505 )
into aprende ( id_persona , codigo_hechizo ) values ( 25 , 105 )
into aprende ( id_persona , codigo_hechizo ) values ( 26 , 201 )
into aprende ( id_persona , codigo_hechizo ) values ( 26 , 301 )
into aprende ( id_persona , codigo_hechizo ) values ( 26 , 401 )
into aprende ( id_persona , codigo_hechizo ) values ( 27 , 502 )
into aprende ( id_persona , codigo_hechizo ) values ( 27 , 102 )
into aprende ( id_persona , codigo_hechizo ) values ( 27 , 202 )
into aprende ( id_persona , codigo_hechizo ) values ( 28 , 303 )
into aprende ( id_persona , codigo_hechizo ) values ( 28 , 403 )
into aprende ( id_persona , codigo_hechizo ) values ( 28 , 503 )
into aprende ( id_persona , codigo_hechizo ) values ( 29 , 104 )
into aprende ( id_persona , codigo_hechizo ) values ( 29 , 204 )
into aprende ( id_persona , codigo_hechizo ) values ( 29 , 304 )
select * from dual;
--Cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota)
insert ALL
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 10, 101, 0, 1999, 20)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 10, 102, 1, 1999, 20)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 10, 103, 2, 1999, 20)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 10, 104, 3, 1999, 20)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 10, 105, 4, 1999, 20)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 10, 106, 5, 1999, 20)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 10, 107, 6, 1999, 20)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 10, 108, 7, 1999, 20)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 10, 109, 8, 1999, 20)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 10, 110, 9, 1999, 20)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 11, 101, 0, 1999, 15)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 11, 102, 1, 1999, 15)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 11, 103, 2, 1999, 15)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 11, 104, 3, 1999, 15)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 11, 105, 4, 1999, 15)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 11, 106, 5, 1999, 15)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 11, 107, 6, 1999, 15)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 11, 108, 7, 1999, 15)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 11, 109, 8, 1999, 15)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 11, 110, 9, 1999, 15)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 12, 101, 0, 1999, 20)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 12, 102, 1, 1999, 20)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 12, 103, 2, 1999, 20)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 12, 104, 3, 1999, 20)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 12, 105, 4, 1999, 20)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 12, 106, 5, 1999, 20)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 12, 107, 6, 1999, 20)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 12, 108, 7, 1999, 20)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 12, 109, 8, 1999, 20)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 12, 110, 9, 1999, 20)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 13, 101, 0, 1999, 11)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 13, 102, 1, 1999, 11)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 13, 103, 2, 1999, 11)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 13, 104, 3, 1999, 11)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 13, 105, 4, 1999, 11)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 13, 106, 5, 1999, 11)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 13, 107, 6, 1999, 11)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 13, 108, 7, 1999, 11)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 13, 109, 8, 1999, 11)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 13, 110, 9, 1999, 11)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 14, 101, 0, 1999, 13)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 14, 102, 1, 1999, 13)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 14, 103, 2, 1999, 13)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 14, 104, 3, 1999, 13)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 14, 105, 4, 1999, 13)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 14, 106, 5, 1999, 13)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 14, 107, 6, 1999, 13)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 14, 108, 7, 1999, 13)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 14, 109, 8, 1999, 13)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 14, 110, 9, 1999, 13)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 15, 101, 0, 1999, 14)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 15, 102, 1, 1999, 14)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 15, 103, 2, 1999, 14)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 15, 104, 3, 1999, 14)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 15, 105, 4, 1999, 14)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 15, 106, 5, 1999, 14)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 15, 107, 6, 1999, 14)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 15, 108, 7, 1999, 14)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 15, 109, 8, 1999, 14)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 15, 110, 9, 1999, 14)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 16, 101, 0, 1999, 16)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 16, 102, 1, 1999, 16)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 16, 103, 2, 1999, 16)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 16, 104, 3, 1999, 16)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 16, 105, 4, 1999, 16)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 16, 106, 5, 1999, 16)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 16, 107, 6, 1999, 16)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 16, 108, 7, 1999, 16)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 16, 109, 8, 1999, 16)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 16, 110, 9, 1999, 16)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 17, 101, 0, 1999, 17)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 17, 102, 1, 1999, 17)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 17, 103, 2, 1999, 17)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 17, 104, 3, 1999, 17)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 17, 105, 4, 1999, 17)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 17, 106, 5, 1999, 17)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 17, 107, 6, 1999, 17)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 17, 108, 7, 1999, 17)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 17, 109, 8, 1999, 17)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 17, 110, 9, 1999, 17)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 18, 101, 0, 1999, 10)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 18, 102, 1, 1999, 10)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 18, 103, 2, 1999, 10)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 18, 104, 3, 1999, 10)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 18, 105, 4, 1999, 10)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 18, 106, 5, 1999, 10)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 18, 107, 6, 1999, 10)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 18, 108, 7, 1999, 10)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 18, 109, 8, 1999, 10)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 18, 110, 9, 1999, 10)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 19, 101, 0, 1999, 12)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 19, 102, 1, 1999, 12)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 19, 103, 2, 1999, 12)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 19, 104, 3, 1999, 12)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 19, 105, 4, 1999, 12)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 19, 106, 5, 1999, 12)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 19, 107, 6, 1999, 12)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 19, 108, 7, 1999, 12)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 19, 109, 8, 1999, 12)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 19, 110, 9, 1999, 12)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 20, 101, 0, 1999, 13)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 20, 102, 1, 1999, 13)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 20, 103, 2, 1999, 13)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 20, 104, 3, 1999, 13)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 20, 105, 4, 1999, 13)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 20, 106, 5, 1999, 13)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 20, 107, 6, 1999, 13)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 20, 108, 7, 1999, 13)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 20, 109, 8, 1999, 13)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 20, 110, 9, 1999, 13)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 21, 101, 0, 1999, 08)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 21, 102, 1, 1999, 08)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 21, 103, 2, 1999, 08)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 21, 104, 3, 1999, 08)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 21, 105, 4, 1999, 08)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 21, 106, 5, 1999, 08)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 21, 107, 6, 1999, 08)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 21, 108, 7, 1999, 08)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 21, 109, 8, 1999, 08)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 21, 110, 9, 1999, 08)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 22, 101, 0, 1999, 11)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 22, 102, 1, 1999, 11)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 22, 103, 2, 1999, 11)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 22, 104, 3, 1999, 11)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 22, 105, 4, 1999, 11)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 22, 106, 5, 1999, 11)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 22, 107, 6, 1999, 11)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 22, 108, 7, 1999, 11)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 22, 109, 8, 1999, 11)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 22, 110, 9, 1999, 11)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 23, 101, 0, 1999, 10)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 23, 102, 1, 1999, 10)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 23, 103, 2, 1999, 10)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 23, 104, 3, 1999, 10)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 23, 105, 4, 1999, 10)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 23, 106, 5, 1999, 10)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 23, 107, 6, 1999, 10)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 23, 108, 7, 1999, 10)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 23, 109, 8, 1999, 10)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 23, 110, 9, 1999, 10)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 24, 101, 0, 1999, 13)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 24, 102, 1, 1999, 13)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 24, 103, 2, 1999, 13)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 24, 104, 3, 1999, 13)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 24, 105, 4, 1999, 13)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 24, 106, 5, 1999, 13)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 24, 107, 6, 1999, 13)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 24, 108, 7, 1999, 13)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 24, 109, 8, 1999, 13)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 24, 110, 9, 1999, 13)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 25, 101, 0, 1999, 11)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 25, 102, 1, 1999, 11)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 25, 103, 2, 1999, 11)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 25, 104, 3, 1999, 11)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 25, 105, 4, 1999, 11)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 25, 106, 5, 1999, 11)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 25, 107, 6, 1999, 11)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 25, 108, 7, 1999, 11)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 25, 109, 8, 1999, 11)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 25, 110, 9, 1999, 11)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 26, 101, 0, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 26, 102, 1, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 26, 103, 2, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 26, 104, 3, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 26, 105, 4, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 26, 106, 5, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 26, 107, 6, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 26, 108, 7, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 26, 109, 8, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 26, 110, 9, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 27, 101, 0, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 27, 102, 1, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 27, 103, 2, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 27, 104, 3, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 27, 105, 4, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 27, 106, 5, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 27, 107, 6, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 27, 108, 7, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 27, 109, 8, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 27, 110, 9, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 28, 101, 0, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 28, 102, 1, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 28, 103, 2, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 28, 104, 3, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 28, 105, 4, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 28, 106, 5, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 28, 107, 6, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 28, 108, 7, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 28, 109, 8, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 28, 110, 9, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 29, 101, 0, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 29, 102, 1, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 29, 103, 2, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 29, 104, 3, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 29, 105, 4, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 29, 106, 5, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 29, 107, 6, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 29, 108, 7, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 29, 109, 8, 1999, 09)
into cursa ( id_estudiante , codigo_materia , id_profesor , anio_escolar , nota) values ( 29, 110, 9, 1999, 09)
select * from dual;
--Grupo_Hechizo ( id_grupo , codigo_hechizo_1 , codigo_hechizo_2 , codigo_hechizo_3 , codigo_hechizo_4 , codigo_hechizo_5, codigo_hechizo_6 )
insert ALL
into grupo_hechizo ( id_grupo, codigo_hechizo_1, codigo_hechizo_2, codigo_hechizo_3, codigo_hechizo_4, codigo_hechizo_5, codigo_hechizo_6) values (1,101,201,301,405,505,105)
into grupo_hechizo ( id_grupo, codigo_hechizo_1, codigo_hechizo_2, codigo_hechizo_3, codigo_hechizo_4, codigo_hechizo_5, codigo_hechizo_6) values (2,102,202,302,405,505,105)
into grupo_hechizo ( id_grupo, codigo_hechizo_1, codigo_hechizo_2, codigo_hechizo_3, codigo_hechizo_4, codigo_hechizo_5, codigo_hechizo_6) values (3,303,403,503,201,301,401)
into grupo_hechizo ( id_grupo, codigo_hechizo_1, codigo_hechizo_2, codigo_hechizo_3, codigo_hechizo_4, codigo_hechizo_5, codigo_hechizo_6) values (4,104,204,304,201,301,401)
into grupo_hechizo ( id_grupo, codigo_hechizo_1, codigo_hechizo_2, codigo_hechizo_3, codigo_hechizo_4, codigo_hechizo_5, codigo_hechizo_6) values (5,201,301,401,201,301,401)
into grupo_hechizo ( id_grupo, codigo_hechizo_1, codigo_hechizo_2, codigo_hechizo_3, codigo_hechizo_4, codigo_hechizo_5, codigo_hechizo_6) values (6,502,102,202,201,301,401)
into grupo_hechizo ( id_grupo, codigo_hechizo_1, codigo_hechizo_2, codigo_hechizo_3, codigo_hechizo_4, codigo_hechizo_5, codigo_hechizo_6) values (7,303,403,503,502,102,202)
into grupo_hechizo ( id_grupo, codigo_hechizo_1, codigo_hechizo_2, codigo_hechizo_3, codigo_hechizo_4, codigo_hechizo_5, codigo_hechizo_6) values (8,303,403,503,303,403,503)
into grupo_hechizo ( id_grupo, codigo_hechizo_1, codigo_hechizo_2, codigo_hechizo_3, codigo_hechizo_4, codigo_hechizo_5, codigo_hechizo_6) values (9,104,204,304,502,102,202)
into grupo_hechizo ( id_grupo, codigo_hechizo_1, codigo_hechizo_2, codigo_hechizo_3, codigo_hechizo_4, codigo_hechizo_5, codigo_hechizo_6) values (10,104,204,304,303,403,503)
into grupo_hechizo ( id_grupo, codigo_hechizo_1, codigo_hechizo_2, codigo_hechizo_3, codigo_hechizo_4, codigo_hechizo_5, codigo_hechizo_6) values (11,104,204,304,104,204,304)
select * from dual;
--Batalla ( id_estudiante _ 1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador)
insert ALL
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 10, 15, 1, TO_DATE('13/06/1993','dd/mm/yyyy') , 'Colegio', 10)
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 10, 20, 1, TO_DATE('14/06/1993','dd/mm/yyyy') , 'Ciudad', 10)
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 10, 25, 1, TO_DATE('15/06/1993','dd/mm/yyyy') , 'Campo', 10)
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 11, 15, 2, TO_DATE('16/06/1993','dd/mm/yyyy') , 'Colegio', 11)
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 11, 20, 2, TO_DATE('17/06/1993','dd/mm/yyyy') , 'Ciudad', 20)
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 11, 25, 2, TO_DATE('18/06/1993','dd/mm/yyyy') , 'Campo', 11)
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 12, 15, 1, TO_DATE('19/06/1993','dd/mm/yyyy') , 'Colegio', 12)
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 12, 20, 1, TO_DATE('12/06/1993','dd/mm/yyyy') , 'Ciudad', 20)
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 12, 25, 1, TO_DATE('11/06/1993','dd/mm/yyyy') , 'Campo', 25)
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 13, 16, 3, TO_DATE('10/06/1993','dd/mm/yyyy') , 'Colegio', 13)
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 13, 21, 3, TO_DATE('10/07/1993','dd/mm/yyyy') , 'Ciudad', 13)
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 13, 26, 3, TO_DATE('11/07/1993','dd/mm/yyyy') , 'Campo', 13)
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 14, 16, 4, TO_DATE('12/07/1993','dd/mm/yyyy') , 'Colegio', 14)
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 14, 21, 4, TO_DATE('13/07/1993','dd/mm/yyyy') , 'Ciudad', 14)
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 14, 26, 4, TO_DATE('14/07/1993','dd/mm/yyyy') , 'Campo', 14)
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 16, 21, 5, TO_DATE('15/07/1993','dd/mm/yyyy') , 'Colegio', 21)
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 17, 22, 6, TO_DATE('16/07/1993','dd/mm/yyyy') , 'Ciudad', 22)
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 17, 26, 5, TO_DATE('17/07/1993','dd/mm/yyyy') , 'Campo', 26)
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 17, 27, 6, TO_DATE('18/07/1993','dd/mm/yyyy') , 'Colegio', 17)
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 18, 22, 7, TO_DATE('19/07/1993','dd/mm/yyyy') , 'Ciudad', 18)
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 18, 27, 7, TO_DATE('10/08/1993','dd/mm/yyyy') , 'Campo', 18)
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 18, 28, 8, TO_DATE('11/08/1993','dd/mm/yyyy') , 'Colegio', 28)
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 19, 22, 9, TO_DATE('12/08/1993','dd/mm/yyyy') , 'Ciudad', 19)
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 19, 27, 9, TO_DATE('13/08/1993','dd/mm/yyyy') , 'Campo', 27)
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 19, 28, 10, TO_DATE('14/08/1993','dd/mm/yyyy') , 'Colegio', 28)
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 23, 18, 8, TO_DATE('15/08/1993','dd/mm/yyyy') , 'Ciudad', 23)
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 23, 28, 8, TO_DATE('16/08/1993','dd/mm/yyyy') , 'Campo', 23)
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 29, 23, 10, TO_DATE('17/08/1993','dd/mm/yyyy') , 'Colegio', 23)
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 24, 19, 11, TO_DATE('18/08/1993','dd/mm/yyyy') , 'Ciudad', 24)
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 24, 26, 4, TO_DATE('19/08/1993','dd/mm/yyyy') , 'Campo', 24)
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 24, 29, 11, TO_DATE('10/09/1993','dd/mm/yyyy') , 'Colegio', 24)
into batalla ( id_estudiante_1 , id_estudiante_2 , id_grupo_hechizo , fecha , lugar, ganador) values ( 29, 21, 4, TO_DATE('11/09/1993','dd/mm/yyyy') , 'Ciudad', 21)
select * from dual;










