{-
PROYECTO 1 Semestre: 2-2017
ARMANDO RIVAS CI:24205909
JOSE ALONSO CI:25213481
Fecha: 23/04/2018
-}


import Data.List
import Data.Char
data Casilla = Obstaculo Int
data Laberinto = Posicion Casilla Int Int

--no recuerdo que hace poner fino jeje
poner_fino :: Int->Int->[[Int]]->[[Int]]
poner_fino i j (x:xs) = if j <= 0 then (poner_fino1 i x):xs else x:poner_fino i (j-1) xs

--inserta 6 en la ultima posicion
poner_fino1 :: Int->[Int]->[Int]
poner_fino1 i (x:xs) = if i <= 0 then ((x+6):xs) else x:poner_fino1 (i-1) xs

--inserta 18 en la primera posicion y llama a poner fino
poner_fino2 :: Int->Int->[[Int]]->[[Int]]
poner_fino2 i j ((y:ys):ls) = poner_fino i j ((y+18:ys):ls)

--inserta los valores en la posicion que debe ir en una lista de lista
poner_finog :: Int->Int->Int->[[Int]]->[[Int]]
poner_finog t i j (x:xs) = if i <= 0 then (insertAt t j x):xs else x:poner_finog t (i-1) j xs

--crea matriz de ceros
crear_mat :: Int->Int->[[Int]]
crear_mat x y = replicate y (replicate x 0)

--inserta el valor x en la posicion y de una lista
insertAt :: Int -> Int -> [Int] -> [Int]
insertAt newElement _ [] = [newElement]
insertAt newElement i (a:as)
  | i == 0 = (newElement+a):as
  | otherwise = a : insertAt newElement (i - 1) as

--inserta recursivamente los elementos de la lista laberinto en la lista de lista
insertar_val :: [Laberinto]->[[Int]]->[[Int]]
insertar_val [] l = l
insertar_val ((Posicion (Obstaculo t) x y):xs) l = insertar_val xs (poner_finog t x y l)

--genera el laberinto con la los elementos de la lista ya introducidos
generar_laberinto :: ([Laberinto],Int,Int)->[[Int]]
generar_laberinto ([], x, y) = poner_fino2 (x-1) (y-1) (crear_mat x y)
generar_laberinto (l, x, y) = insertar_val l (poner_fino2 (x-1) (y-1) (crear_mat x y))

--hace el calculo de el montapuercos contra los obstaculos
plomeo :: (Int,Int)->(Int,Int)->(Int,Int)
plomeo (x1,x2) (y1,y2)
 | y1<=0 =(x1,x2)
 | x1<=0 =(0,x2)
 | y1-x2<=0 = (x1,x2)
 | otherwise = plomeo ((x1-y2),x2) ((y1-x2),y2)

--devuelve una tupla con los valores de los obstaculos
obtenerobstaculo :: Int->(Int,Int)
obtenerobstaculo x | x==1 = (742,158) | x==2 = (954,190) | x==3 = (1672,110) | x==4 = (1408,300)
 | otherwise = (0,0)

{-ACA DEBES ESCRIBIR EL RESTO DE LAS CONDICIONES QUE SON:
 		1) SI LA VIDA ES <= 0 Y ESTA FUERA DE LOS LIMITES (LISTO)
 		2) SI LA CASILLA ES UN 5 (DUDAS CON LA DIRECCION Q PUEDE IR, asumimos que estando en el puente puedes ir a cualquier direccion excepto a la anterior o a otro 5)
 		3) SI LA CASILLA ES UN 6 (LISTO)
 		4) SI LA POSICION ES IGUAL A LA ANTERIOR (LISTO)
 		5) SI LA CASILLA ES UN 5 Y LA SIGUIENTE TAMBIEN (LISTO)
 		6) OTHERWISE HARA LA LLAMADA RECURSIVA CON LA VIDA MODIFICADA (LISTO)
 	-}

validarcas :: [[Int]]->(Int,Int)->(Int,Int)->(Int,Int)->Bool
validarcas (x:xs) (x1,x2) (y1,y2) (v1,v2)
 | ( (v1<=0) || (x1==length(x:xs)) || (x2==length(x)) || (x1<0) || (x2<0) || (y1<0) || (y2<0) || (y1==length(x:xs)) || (y2==length(x))) = False
 | ((x:xs)!!x1)!!x2 == 6 = if v1>0 then True else False
 | (((x:xs)!!x1)!!x2 == 5 && ((x:xs)!!y1)!!y2 == 5) = False
 | (x1==y1) && (x2==y2) = False
 | ((x:xs)!!x1)!!x2 == 18 = False
 | ((x:xs)!!x1)!!x2 == 5 = validarcas (x:xs) (x1,(x2+1)) (x1,x2) (v1,v2) || validarcas (x:xs) ((x1+1),x2) (x1,x2) (v1,v2) || validarcas (x:xs) (x1,(x2-1)) (x1,x2) (v1,v2) || validarcas (x:xs) ((x1-1),x2) (x1,x2) (v1,v2)
 | otherwise = validarcas (x:xs) (x1,(x2+1)) (x1,x2) (plomeo (v1,v2) (obtenerobstaculo (((x:xs)!!x1)!!x2))) || validarcas (x:xs) ((x1+1),x2) (x1,x2) (plomeo (v1,v2) (obtenerobstaculo (((x:xs)!!x1)!!x2))) || validarcas (x:xs) (x1,(x2-1)) (x1,x2) (plomeo (v1,v2) (obtenerobstaculo (((x:xs)!!x1)!!x2))) || validarcas (x:xs) ((x1-1),x2) (x1,x2) (plomeo (v1,v2) (obtenerobstaculo (((x:xs)!!x1)!!x2)))

--hace el llamado de validar casillas con las posiciones adyacentes al 18 que son: (0,1) y (1,0)
iSolucion :: [[Int]]->Bool
iSolucion [] = False
iSolucion l = validarcas l (1,0) (0,0) (2000,500) || validarcas l (0,1) (0,0) (2000,500)


validarcas2 :: [[Int]]->(Int,Int)->(Int,Int)->(Int,Int)->(Int,Int)
validarcas2 (x:xs) (x1,x2) (y1,y2) (v1,v2)
 | ( (v1<=0) || (x1==length(x:xs)) || (x2==length(x)) || (x1<0) || (x2<0) || (y1<0) || (y2<0) || (y1==length(x:xs)) || (y2==length(x))) = (0,v2)
 | ((x:xs)!!x1)!!x2 == 6 = if v1>0 then (v1,v2) else (0,v2)
 | (((x:xs)!!x1)!!x2 == 5 && ((x:xs)!!y1)!!y2 == 5) = (0,v2)
 | (x1==y1) && (x2==y2) = (0,v2)
 | ((x:xs)!!x1)!!x2 == 18 = (0,v2)
 | ((x:xs)!!x1)!!x2 == 5 = validarcas2 (x:xs) (ironman (x:xs) (x1,x2)) (x1,x2) (v1,v2)
 | otherwise = validarcas2 (x:xs) (ironman (x:xs) (x1,x2)) (x1,x2) (plomeo (v1,v2) (obtenerobstaculo (((x:xs)!!x1)!!x2) ) )

--AQUI IRONMAN LE CLAVA EL ESCUDO A CAPITAN AMERICA... COMPARA DEPENDIENDO DE EN QUE POSICION DE LA MATRIZ ESTA
ironman :: [[Int]]->(Int,Int)->(Int,Int)
ironman (x:xs) (x1,y1)
 | (x1==(length(x:xs)-1) && y1==(length(x)-1)) = (x1,y1)--ESTOY EN EL FINAL
 | x1==0 && y1==0 = if ( ((x:xs)!!x1)!!(y1+1) <= ((x:xs)!!(x1+1))!!y1 || ((x:xs)!!x1)!!(y1+1) == 6) then ((x1,(y1+1))) else ((x1+1),y1)--ESTOY EN EL PRINCIPIO
 | (x1==(length(x:xs)-1) && y1==0) = if ( ((x:xs)!!(x1-1))!!y1 <= ((x:xs)!!x1)!!(y1+1) || ((x:xs)!!(x1-1))!!y1==6) then ((x1-1),y1) else (x1,(y1+1))--ESTOY EN LA ESQUINA INFERIOR IZQUIERDA
 | (x1==0 && y1==(length x)-1) = if ( ((x:xs)!!(x1+1))!!y1 <= ((x:xs)!!x1)!!(y1-1) || ((x:xs)!!(x1+1))!!y1 == 6 ) then ((x1+1),y1) else (x1,(y1-1))--ESTOY EN LA ESQUINA SUPERIOR DERECHA
 | x1==(length(x:xs)-1) = if ( (((x:xs)!!x1)!!(y1+1)<=((x:xs)!!x1)!!(y1-1) && ((x:xs)!!x1)!!(y1+1)<=((x:xs)!!(x1-1))!!y1 ) || ((x:xs)!!x1)!!(y1+1)==6 ) then (x1,(y1+1)) else ( if ( (((x:xs)!!(x1-1))!!y1)<=((x:xs)!!x1)!!(y1-1) || (((x:xs)!!(x1-1))!!y1)==6 ) then ((x1-1),y1) else (x1,(y1-1)) )--ESTOY EN EL PISO
 | x1==0 = if ( (((x:xs)!!x1)!!(y1+1)<=((x:xs)!!x1)!!(y1-1) && ((x:xs)!!x1)!!(y1+1)<=((x:xs)!!(x1+1))!!y1 ) || ((x:xs)!!x1)!!(y1+1)==6 ) then (x1,(y1+1)) else ( if ( (((x:xs)!!(x1+1))!!y1)<=((x:xs)!!x1)!!(y1-1) || (((x:xs)!!(x1+1))!!y1)==6 ) then ((x1+1),y1) else (x1,(y1-1)) )--ESTOY EN EL TECHO
 | y1==(length(x)-1) = if ( (((x:xs)!!(x1+1))!!y1<=((x:xs)!!(x1-1))!!y1 && ((x:xs)!!(x1+1))!!y1 <= ((x:xs)!!x1)!!(y1-1)) || ((x:xs)!!(x1+1))!!y1==6 ) then ((x1+1),y1) else ( if (((x:xs)!!(x1-1))!!y1<=((x:xs)!!x1)!!(y1-1)) then ((x1-1),y1) else (x1,(y1-1)) )--ESTOY EN LA PARED DERECHA
 | y1==0 = if (((x:xs)!!x1)!!(y1+1)<=((x:xs)!!(x1+1))!!y1 && ((x:xs)!!x1)!!(y1+1) <= ((x:xs)!!(x1-1))!!y1 || ((x:xs)!!x1)!!(y1+1)==6 ) then (x1,(y1+1)) else ( if ((x:xs)!!(x1+1))!!y1 <= ((x:xs)!!(x1-1))!!y1  then ((x1+1),y1) else ((x1+1),y1) )--ESTOY EN LA PARED IZQUIERDA
 | ((x:xs)!!x1)!!(y1+1) <= ((x:xs)!!x1)!!(y1-1) && ((x:xs)!!x1)!!(y1+1) <= ((x:xs)!!(x1-1))!!y1 && ((x:xs)!!x1)!!(y1+1) <= ((x:xs)!!(x1+1))!!y1 || ((x:xs)!!x1)!!(y1+1) == 6 = (x1,(y1+1))--LAS QUE QUEDAN ES PQ ESTA EN EL MEDIO DE LA MATRIZ
 | ((x:xs)!!(x1-1))!!y1 <= ((x:xs)!!x1)!!(y1-1) && ((x:xs)!!(x1-1))!!y1 <= ((x:xs)!!x1)!!(y1+1) && ((x:xs)!!(x1-1))!!y1 <= ((x:xs)!!(x1+1))!!y1 || ((x:xs)!!(x1-1))!!y1 == 6 = ((x1-1),y1)
 | ((x:xs)!!(x1+1))!!y1 <= ((x:xs)!!x1)!!(y1-1) && ((x:xs)!!(x1+1))!!y1 <= ((x:xs)!!x1)!!(y1+1) && ((x:xs)!!(x1+1))!!y1 <= ((x:xs)!!(x1-1))!!y1 || ((x:xs)!!(x1+1))!!y1 == 6 = ((x1+1),y1)
 | ((x:xs)!!x1)!!(y1-1) <= ((x:xs)!!x1)!!(y1+1) && ((x:xs)!!x1)!!(y1-1) <= ((x:xs)!!(x1-1))!!y1 && ((x:xs)!!x1)!!(y1-1) <= ((x:xs)!!(x1+1))!!y1 || ((x:xs)!!x1)!!(y1-1) == 6 = (x1,(y1-1))

solucion_max_salud :: [[Int]] -> Int
solucion_max_salud l = max (fst(validarcas2 l (0,1) (0,0) (2000,500))) (fst(validarcas2 l (1,0) (0,0) (2000,500)))

