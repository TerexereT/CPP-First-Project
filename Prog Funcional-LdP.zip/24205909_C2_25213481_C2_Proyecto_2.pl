%Jose Alonso	25213481
%Armando Rivas 	24205909

% AQUI COMIENZA EL EJERCICIO 1


%en la llamada pasarle en L2 una lista vacia
replicate1(0,_,X,X):-!.
replicate1(C,L1,L2,L):-
	Aux is C-1,
	append(L1,L2,L3),
	replicate1(Aux,L1,L3,L).

same([], []):-!.
same([H1|R1], [H2|R2]):-
    H1 = H2,
    same(R1, R2).

ironman(S,1,Sr):-
	atom_codes(S,Lx),
	length(Lx,Nx),
	take(1,Lx,Rx),
	Aux2 is div(Nx,1),
	replicate1(Aux2,Rx,[],Ry),
	(same(Lx,Ry)
 		-> length(Rx,Sr);
 		Sr is 9999999
 		),!.
ironman(S,Is,Sr):-
 atom_codes(S,Lx),
 length(Lx,Nx),
 (Is>1
 	->
 	Aux1 is mod(Nx,Is),
 	(Aux1==0
 		->
 		take(Is,Lx,Rx),
 		Aux2 is div(Nx,Is),
 		replicate1(Aux2,Rx,[],Ry),
 		(same(Lx,Ry)
 			-> length(Rx,Sr)
 			;
 			Sr is 9999999
 		),
 		true
 	;
 		Sr is 9999999
 		%Is1 is Is-1,
   		%ironman(S,Is1,Sr)
 	)
 ).

add_tail([],X,[X]).
add_tail([H|T],X,[H|L]):-add_tail(T,X,L).

constructor(_,1,L1,L2):-add_tail(L1,1,L2),!.
constructor(N,M,L1,L):-
	Aux is mod(N,M),
	( Aux == 0  
		->
		(M>=1
			->
		add_tail(L1,M,L3),
		M1 is M-1,
		constructor(N,M1,L3,L)
		)
	;
	M1 is M-1,
	constructor(N,M1,L1,L)
		
	).

valicons([],_,La,La).
valicons([H|T],S,La,Lr):-
	ironman(S,H,Iv),
		(Iv=\=9999999
			->
			add_tail(La,Iv,L2)
		;
		valicons(T,S,La,Lr),!
		),
		valicons(T,S,L2,Lr),!.

n_periodo(S, N):-
	atom_codes(S,L1),
	length(L1,Long),
	constructor(Long,Long,[],L2),
	valicons(L2,S,[],L3),
	last(L3,N).


% AQUI TERMINA EL EJERCICIO NUMERO 1

%AQUI EMPIEZA EL EJERCICIO NUMERO 2

ocurrencias(S,N):-
	n_periodo(S,Aux1),
	atom_codes(S,L1),
	length(L1,Aux2),
	N is div(Aux2,Aux1).

%AQUI TERMINA EL EJERCICIO NUMERO 2

%AQUI COMIENZA EL EJERCICIO NUMERO 3

cifrar(Sx,L):-
 string_to_list(Sx,Lx),
 reverse(Lx,Ly),
 peligro(Ly,[],Reversed1),
 atomic_list_concat(Reversed1, '', Atom),
 atom_string(Atom, L).

peligro([],Res,Res).
peligro([X|Xs],Acc,Res):-
 num_reversed(X,Wx),
 peligro(Xs,[Wx|Acc],Wy),
 reverse(Wy,Res).

num_reversed(Num, Reversed) :-
   number_chars(Num, Chars),
   reverse(Chars, Reversed1),
atomic_list_concat(Reversed1, '', Atom), atom_string(Atom, Reversed).

repl(X, N, L) :-
    length(L, N),
    maplist(=(X), L).

take(N, _, Xs) :- N =< 0, !, N =:= 0, Xs = [].
take(_, [], []).
take(N, [X|Xs], [X|Ys]) :- M is N-1, take(M, Xs, Ys).

test(N,X) :- X is N mod 10.

compare_list([],_).
compare_list([L1Head|L1Tail], List2):-
    member(L1Head, List2),
    compare_list(L1Tail, List2),!.

str_to_list([], []).
str_to_list([C|Cs], [E|Es]) :-
    char_to_el(C, E),
    str_to_list(Cs, Es).

bc('3','2'," "):-!.
bc('3','3',"!"):-!.
bc('4','4',","):-!.
bc('4','6',"."):-!.
bc('5','8',":"):-!.
bc('5','9',";"):-!.
bc('6','3',"?"):-!.
bc('6','5',"A"):-!.
bc('6','6',"B"):-!.
bc('6','7',"C"):-!.
bc('6','8',"D"):-!.
bc('6','9',"E"):-!.
bc('7','0',"F"):-!.
bc('7','1',"G"):-!.
bc('7','2',"H"):-!.
bc('7','3',"I"):-!.
bc('7','4',"J"):-!.
bc('7','5',"K"):-!.
bc('7','6',"L"):-!.
bc('7','7',"M"):-!.
bc('7','8',"N"):-!.
bc('7','9',"O"):-!.
bc('8','0',"P"):-!.
bc('8','1',"Q"):-!.
bc('8','2',"R"):-!.
bc('8','3',"S"):-!.
bc('8','4',"T"):-!.
bc('8','5',"U"):-!.
bc('8','6',"V"):-!.
bc('8','7',"W"):-!.
bc('8','8',"X"):-!.
bc('8','9',"Y"):-!.
bc('9','0',"Z"):-!.
bc('9','7', "a"):-!.
bc('9','8', "b"):-!.
bc('9','9', "c"):-!.
bc(_,_,9999999):-!.
bcc('1','0','0', "d"):-!.
bcc('1','0','1', "e"):-!.
bcc('1','0','2', "f"):-!.
bcc('1','0','3', "g"):-!.
bcc('1','0','4', "h"):-!.
bcc('1','0','5', "i"):-!.
bcc('1','0','6', "j"):-!.
bcc('1','0','7', "k"):-!.
bcc('1','0','8', "l"):-!.
bcc('1','0','9', "m"):-!.
bcc('1','1','0', "n"):-!.
bcc('1','1','1', "o"):-!.
bcc('1','1','2', "p"):-!.
bcc('1','1','3', "q"):-!.
bcc('1','1','4', "r"):-!.
bcc('1','1','5', "s"):-!.
bcc('1','1','6', "t"):-!.
bcc('1','1','7', "u"):-!.
bcc('1','1','8', "v"):-!.
bcc('1','1','9', "w"):-!.
bcc('1','2','0', "x"):-!.
bcc('1','2','1', "y"):-!.
bcc('1','2','2', "z"):-!.
bcc(_,_,_, 9999999):-!.

robin([],S2,S2).
robin([X,Y|T],S2,Sr):-
	bc(X,Y,Q),
	(Q=:=9999999
		->string_concat(S2,"",Sr);
		string_concat(S2,Q,S3),
		robin(T,S3,Sr)
		).

batman([],S2,S2):-!.
batman([X,Y,Z|T],S2,Sr):-
	bc(X,Y,W),
	(W=:=9999999
		->
		bcc(X,Y,Z,Px),
		(Px=:=9999999
			->string_concat(S2,"",Sr)

		;
		string_concat(S2,Px,S3),
		length(T,Aux),

			(Aux=:=2 
				-> 
				robin([Z|T],S3,Sr)
				;
				batman(T,S3,Sr)
			)
			
		)
	;
	string_concat(S2,W,S3),

	length([Z|T],Aux),
	(Aux==2 
		-> 
		robin([Z|T],S3,Sr)
		;
		batman([Z|T],S3,Sr)
		),
	%batman([Z|T],S3,Sr),
	!
	).


decifrar(S,Sr):-
	string_chars(S,L1),
	reverse(L1,L2),
	batman(L2,"",Sr).
	
transformar(1,S,M):-cifrar(S,M),!.
transformar(0,S,M):-decifrar(S,M),!.

%AQUI TERMINA EL EJERCICIO NUMERO 3