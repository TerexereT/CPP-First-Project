Universidad Central de Venezuela

Facultad de Ciencias

Escuela de Computaci�n

Lenguajes de Programacion

Proyecto 2

Integrantes: Alonso, Jose



                     Rivas, Armando


 

Nuestro proyecto consta de 3 funciones principales descritas por el enunciado del proyecto: n_periodo, ocurrencias y transformar, que a su vez estas funciones estan definidas mediante otras funciones, ya sean hechas por nosotros o funciones que pertenecen al preludio de Prolog.

 

Para la funcion n_periodo usamos las funciones: 

 

�    replicate1: replica una lista n veces.

 

�    same: nos dice si dos listas son exactamente iguales.

 

�    ironman: nos arroja el patron de menor tama�o capaz de construir el string dado.

 

�    add_tail: inserta valores en la ultima posicion de una lista que usaremos como referencia ya que el ultimo valor almacenado es el valor que nos va a decir el tama�o del patron, los valores almacenados en esta lista son calculados mediante la funcion constructor.

 

�    constructor: es la funcion que se encarga de calcular los valores que seran almacenados en la lista que opera add_tail. 

 

�    valicons: esta funcion se encarga de insertar en una lista un solo elemento el cual representa el tama�o del patron que construye el string dado, esto lo hace mediante la funcion ironman.

 

Para la funcion ocurrencias usamos las funciones declaradas en la funcion n_periodo, con la unica diferencia que en vez de obtener el mod hicimos un div para obtener el numero de ocurrencias de dicho patron.

 

Para la funcion transformar usamos las funciones:

 

�    cifrar: la cual es una funcion que fue construida con funciones nuestras y funciones del preludio de Prolog, como por ejemplo usamos reverse, string_to_list, atomic_list_concat, atom_string y las funciones hechas por nosotros fueron peligro, num_reversed.

 

�    descifrar: es la funcion encargada de descifrar (como su nombre lo indica) cualquier string que cumpla con las restricciones dadas y eso lo hicimos mediante una base de conocimiento y el proceso inverso de la funcion cifrar, ya que debiamos ir comprobando si al ir descifrando los elementos pertenezcan a la base de conocimiento.